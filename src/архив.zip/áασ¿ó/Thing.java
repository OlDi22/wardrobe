public class Thing {


    float thingPrice; //стоимость вещи

    public Thing(float thingPrice)  {this.thingPrice = thingPrice;}


}
