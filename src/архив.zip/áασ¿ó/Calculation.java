public class Calculation {

    /**
     * Возвращает стоимость всех вещей из счета
     * @param bill счет
     * @return сумма
     */

    public static double getAllSumm(Bill bill)   {

        return bill.count * bill.Thing.thingPrice - bill.count * (bill.Thing.thingPrice * bill.discount.persent / 100);
    }
}
