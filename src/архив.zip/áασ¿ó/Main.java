public class Main {
    public static void main(String[] args) {

        Bill bill1 = new Bill();
        bill1.count = 1;
        bill1.discount = Discount.shirt;
        bill1.shirt = new shirt(19);

        Bill bill2 = new Bill();
        bill2.count = 1;
        bill2.discount = Discount.shirt;
        bill2.shoes = new shoes(41);

        Bill bill3 = new Bill();
        bill3.count = 1;
        bill3.discount = Discount.shirt;
        bill3.business_suit = new business_suit(53);

        Bill bill4 = new Bill();
        bill4.count = 1;
        bill4.discount = Discount.shirt;
        bill4.hat = new hat(25);

        Bill bill5 = new Bill();
        bill5.count = 1;
        bill5.discount = Discount.shirt;
        bill5.coat = new coat(70);

        System.out.println("Общая стоимость вещей:  " + (Calculation.getAllSumm(bill1) + Calculation.getAllSumm(bill2) +
                Calculation.getAllSumm(bill3) + Calculation.getAllSumm(bill4) + Calculation.getAllSumm(bill5)));

    }

    private static class shirt {
        public shirt(int thingPrice) {
        }
    }

    private static class shoes {
        public shoes(int thingPrice) {
        }
    }

    private static class business_suit {
        public business_suit(int thingPrice) {
        }
    }

    private static class hat {
        public hat(int thingPrice) {
        }
    }

    private static class coat {
        public coat(int thingPrice) {
        }

    }
}
