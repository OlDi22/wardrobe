public enum Discount {


    shirt (0),
    shoes (32),
    business_suit (44),
    hat (37),
    coat (77);

    int persent;

    Discount(int persent)  {this.persent = persent;}
}

