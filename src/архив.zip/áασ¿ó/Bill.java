public class Bill {


    public Object shirt;
    public Object shoes;
    public Object business_suit;
    public Object hat;
    public Object coat;
    public Object Thing;

    Discount discount;


    int count;


}
